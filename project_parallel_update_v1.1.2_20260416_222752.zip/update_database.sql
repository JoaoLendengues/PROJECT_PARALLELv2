
-- PROJECT PARALLEL - ATUALIZAÇÃO DO BANCO DE DADOS
-- Versão: 1.1.1 (nenhuma alteração no banco, apenas correções de código)

-- Verificar versão atual
SELECT valor as versao_atual FROM configuracoes WHERE chave = 'versao_sistema';

-- Atualizar versão (opcional)
INSERT INTO configuracoes (chave, valor) VALUES ('versao_sistema', '1.1.1')
ON CONFLICT (chave) DO UPDATE SET valor = '1.1.1';

-- Nota: Esta versão não contém alterações na estrutura do banco,
-- apenas correções no código do frontend.
