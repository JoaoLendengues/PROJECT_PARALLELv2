
-- PROJECT PARALLEL - ATUALIZAÇÃO DO BANCO DE DADOS
-- Versão: 1.1.5

-- Verificar versão atual
SELECT valor as versao_atual FROM configuracoes WHERE chave = 'versao_sistema';

-- Atualizar versão
INSERT INTO configuracoes (chave, valor) VALUES ('versao_sistema', '1.1.5')
ON CONFLICT (chave) DO UPDATE SET valor = '1.1.5';
