PROJECT PARALLEL - PACOTE DE ATUALIZAÇÃO v1.1.5
=============================================

📦 CONTEÚDO DO PACOTE:
- backend/     → Arquivos do servidor (FastAPI)
- desktop/     → Arquivos do cliente (PySide6)
- CHANGELOG.txt → Lista de mudanças
- update_database.sql → Scripts SQL

🚀 COMO ATUALIZAR:

1. BACKEND (servidor):
   - Parar o serviço do backend
   - Substituir os arquivos da pasta 'backend/'
   - Executar o script SQL no PostgreSQL
   - Reiniciar o backend

2. DESKTOP (clientes):
   - Substituir os arquivos da pasta 'desktop/'

Versão: 1.1.5
Data: 20/04/2026 11:40:54
