PROJECT PARALLEL - PACOTE DE ATUALIZAÇÃO v1.1.2
=============================================

📦 CONTEÚDO DO PACOTE:
- backend/     → Arquivos do servidor (FastAPI)
- desktop/     → Arquivos do cliente (PySide6)
- CHANGELOG.txt → Lista de mudanças
- update_database.sql → Scripts SQL (se necessário)

🚀 COMO ATUALIZAR:

1. BACKEND (servidor):
   - Parar o serviço do backend
   - Substituir os arquivos da pasta 'backend/'
   - Executar o script SQL no PostgreSQL (se houver alterações)
   - Reiniciar o backend

2. DESKTOP (clientes):
   - Substituir os arquivos da pasta 'desktop/'
   - Ou substituir apenas os arquivos modificados:
     * widgets/movimentacoes_widget.py
     * widgets/relatorios_widget.py
     * widgets/toast_notification.py
     * core/notification_manager.py
     * version.json
     * version.py

📞 SUPORTE:
Em caso de dúvidas, contate o suporte de TI.

Versão: 1.1.2
Data: 17/04/2026 16:11:25
